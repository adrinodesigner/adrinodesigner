# Aliens-fb

مرحبا مرحبا بكم 

انت تريد تخمين سريع على حساب واختراقه با دقة

هدا سكربت لافضل حقا انه بالغة لعربية 

لن تفقط ضحية تأكيد امان عند لاختراق

تبته

  pkg install python 
  pkg install python2
  pkg install nano 
  pkg install git

git clone https://github.com/hackermohamedPro/Aliens-fb
cd Aliens-fb
python2 Aliens-fb.py

 كلمة شكر

منظمة لإلينز 
محمد برو
